def ChemSymtoZ(ChemSym: str):
    if ChemSym == "H":
        Z = 1
    elif ChemSym == "He":
        Z = 2
    elif ChemSym == "Li":
        Z = 3
    elif ChemSym == "Be":
        Z = 4
    elif ChemSym == "B":
        Z = 5
    elif ChemSym == "C":
        Z = 6
    elif ChemSym == "N":
        Z = 7
    elif ChemSym == "O":
        Z = 8
    elif ChemSym == "F":
        Z = 9
    elif ChemSym == "Ne":
        Z = 10
    elif ChemSym == "Na":
        Z = 11
    elif ChemSym == "Mg":
        Z = 12
    elif ChemSym == "Al":
        Z = 13
    elif ChemSym == "Si":
        Z = 14
    elif ChemSym == "P":
        Z = 15
    elif ChemSym == "S":
        Z = 16
    elif ChemSym == "Cl":
        Z = 17
    elif ChemSym == "Ar":
        Z = 18
    elif ChemSym == "K":
        Z = 19
    elif ChemSym == "Ca":
        Z = 20
    elif ChemSym == "Sc":
        Z = 21
    elif ChemSym == "Ti":
        Z = 22
    elif ChemSym == "V":
        Z = 23
    elif ChemSym == "Cr":
        Z = 24
    elif ChemSym == "Mn":
        Z = 25
    elif ChemSym == "Fe":
        Z = 26
    elif ChemSym == "Co":
        Z = 27
    elif ChemSym == "Ni":
        Z = 28
    elif ChemSym == "Cu":
        Z = 29
    elif ChemSym == "Zn":
        Z = 30
    elif ChemSym == "Ga":
        Z = 31
    elif ChemSym == "Ge":
        Z = 32
    elif ChemSym == "As":
        Z = 33
    elif ChemSym == "Se":
        Z = 34
    elif ChemSym == "Br":
        Z = 35
    elif ChemSym == "Kr":
        Z = 36
    elif ChemSym == "Rb":
        Z = 37
    elif ChemSym == "Sr":
        Z = 38
    elif ChemSym == "Y":
        Z = 39
    elif ChemSym == "Zr":
        Z = 40
    elif ChemSym == "Nb":
        Z = 41
    elif ChemSym == "Mo":
        Z = 42
    elif ChemSym == "Tc":
        Z = 43
    elif ChemSym == "Ru":
        Z = 44
    elif ChemSym == "Rh":
        Z = 45
    elif ChemSym == "Pd":
        Z = 46
    elif ChemSym == "Ag":
        Z = 47
    elif ChemSym == "Cd":
        Z = 48
    elif ChemSym == "In":
        Z = 49
    elif ChemSym == "Sn":
        Z = 50
    elif ChemSym == "Sb":
        Z = 51
    elif ChemSym == "Te":
        Z = 52
    elif ChemSym == "I":
        Z = 53
    elif ChemSym == "Xe":
        Z = 54
    elif ChemSym == "Cs":
        Z = 55
    elif ChemSym == "Ba":
        Z = 56
    elif ChemSym == "La":
        Z = 57
    elif ChemSym == "Ce":
        Z = 58
    elif ChemSym == "Pr":
        Z = 59
    elif ChemSym == "Nd":
        Z = 60
    elif ChemSym == "Pm":
        Z = 61
    elif ChemSym == "Sm":
        Z = 62
    elif ChemSym == "Eu":
        Z = 63
    elif ChemSym == "Gd":
        Z = 64
    elif ChemSym == "Tb":
        Z = 65
    elif ChemSym == "Dy":
        Z = 66
    elif ChemSym == "Ho":
        Z = 67
    elif ChemSym == "Er":
        Z = 68
    elif ChemSym == "Tm":
        Z = 69
    elif ChemSym == "Yb":
        Z = 70
    elif ChemSym == "Lu":
        Z = 71
    elif ChemSym == "Hf":
        Z = 72
    elif ChemSym == "Ta":
        Z = 73
    elif ChemSym == "W":
        Z = 74
    elif ChemSym == "Re":
        Z = 75
    elif ChemSym == "Os":
        Z = 76
    elif ChemSym == "Ir":
        Z = 77
    elif ChemSym == "Pt":
        Z = 78
    elif ChemSym == "Au":
        Z = 79
    elif ChemSym == "Hg":
        Z = 80
    elif ChemSym == "Tl":
        Z = 81
    elif ChemSym == "Pb":
        Z = 82
    elif ChemSym == "Bi":
        Z = 83
    elif ChemSym == "Po":
        Z = 84
    elif ChemSym == "At":
        Z = 85
    elif ChemSym == "Rn":
        Z = 86
    elif ChemSym == "Fr":
        Z = 87
    elif ChemSym == "Ra":
        Z = 88
    elif ChemSym == "Ac":
        Z = 89
    elif ChemSym == "Th":
        Z = 90
    elif ChemSym == "Pa":
        Z = 91
    elif ChemSym == "U":
        Z = 92
    elif ChemSym == "Np":
        Z = 93
    elif ChemSym == "Pu":
        Z = 94
    elif ChemSym == "Am":
        Z = 95
    elif ChemSym == "Cm":
        Z = 96
    elif ChemSym == "Bk":
        Z = 97
    elif ChemSym == "Cf":
        Z = 98
    elif ChemSym == "Es":
        Z = 99
    elif ChemSym == "Fm":
        Z = 100
    elif ChemSym == "Md":
        Z = 101
    elif ChemSym == "No":
        Z = 102
    elif ChemSym == "Lr":
        Z = 103
    elif ChemSym == "Rf":
        Z = 104
    elif ChemSym == "Db":
        Z = 105
    elif ChemSym == "Sg":
        Z = 106
    elif ChemSym == "Bh":
        Z = 107
    elif ChemSym == "Hs":
        Z = 108
    elif ChemSym == "Mt":
        Z = 109
    elif ChemSym == "Ds":
        Z = 110
    elif ChemSym == "Rg":
        Z = 111
    elif ChemSym == "Cn":
        Z = 112
    elif ChemSym == "Nh":
        Z = 113
    elif ChemSym == "Fl":
        Z = 114
    elif ChemSym == "Mc":
        Z = 115
    elif ChemSym == "Lv":
        Z = 116
    elif ChemSym == "Ts":
        Z = 117
    elif ChemSym == "Og":
        Z = 118
    else:
        Z = -1
    return Z
