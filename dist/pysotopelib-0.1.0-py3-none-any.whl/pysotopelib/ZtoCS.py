def ZtoChemSym(Z: int):
    if Z < 1 :        
        return "shit"
    elif Z == 1:
        ChemSym = "H"
    elif Z == 2:
        ChemSym = "He"
    elif Z == 3:
        ChemSym = "Li"
    elif Z == 4:
        ChemSym = "Be"
    elif Z == 5:
        ChemSym = "B"
    elif Z == 6:
        ChemSym = "C"
    elif Z == 7:
        ChemSym = "N"
    elif Z == 8:
        ChemSym = "O"
    elif Z == 9:
        ChemSym = "F"
    elif Z == 10:
        ChemSym = "Ne"
    elif Z == 11:
        ChemSym = "Na"
    elif Z == 12:
        ChemSym = "Mg"
    elif Z == 13:
        ChemSym = "Al"
    elif Z == 14:
        ChemSym = "Si"
    elif Z == 15:
        ChemSym = "P"
    elif Z == 16:
        ChemSym = "S"
    elif Z == 17:
        ChemSym = "Cl"
    elif Z == 18:
        ChemSym = "Ar"
    elif Z == 19:
        ChemSym = "K"
    elif Z == 20:
        ChemSym = "Ca"
    elif Z == 21:
        ChemSym = "Sc"
    elif Z == 22:
        ChemSym = "Ti"
    elif Z == 23:
        ChemSym = "V"
    elif Z == 24:
        ChemSym = "Cr"
    elif Z == 25:
        ChemSym = "Mn"
    elif Z == 26:
        ChemSym = "Fe"
    elif Z == 27:
        ChemSym = "Co"
    elif Z == 28:
        ChemSym = "Ni"
    elif Z == 29:
        ChemSym = "Cu"
    elif Z == 30:
        ChemSym = "Zn"
    elif Z == 31:
        ChemSym = "Ga"
    elif Z == 32:
        ChemSym = "Ge"
    elif Z == 33:
        ChemSym = "As"
    elif Z == 34:
        ChemSym = "Se"
    elif Z == 35:
        ChemSym = "Br"
    elif Z == 36:
        ChemSym = "Kr"
    elif Z == 37:
        ChemSym = "Rb"
    elif Z == 38:
        ChemSym = "Sr"
    elif Z == 39:
        ChemSym = "Y"
    elif Z == 40:
        ChemSym = "Zr"
    elif Z == 41:
        ChemSym = "Nb"
    elif Z == 42:
        ChemSym = "Mo"
    elif Z == 43:
        ChemSym = "Tc"
    elif Z == 44:
        ChemSym = "Ru"
    elif Z == 45:
        ChemSym = "Rh"
    elif Z == 46:
        ChemSym = "Pd"
    elif Z == 47:
        ChemSym = "Ag"
    elif Z == 48:
        ChemSym = "Cd"
    elif Z == 49:
        ChemSym = "In"
    elif Z == 50:
        ChemSym = "Sn"
    elif Z == 51:
        ChemSym = "Sb"
    elif Z == 52:
        ChemSym = "Te"
    elif Z == 53:
        ChemSym = "I"
    elif Z == 54:
        ChemSym = "Xe"
    elif Z == 55:
        ChemSym = "Cs"
    elif Z == 56:
        ChemSym = "Ba"
    elif Z == 57:
        ChemSym = "La"
    elif Z == 58:
        ChemSym = "Ce"
    elif Z == 59:
        ChemSym = "Pr"
    elif Z == 60:
        ChemSym = "Nd"
    elif Z == 61:
        ChemSym = "Pm"
    elif Z == 62:
        ChemSym = "Sm"
    elif Z == 63:
        ChemSym = "Eu"
    elif Z == 64:
        ChemSym = "Gd"
    elif Z == 65:
        ChemSym = "Tb"
    elif Z == 66:
        ChemSym = "Dy"
    elif Z == 67:
        ChemSym = "Ho"
    elif Z == 68:
        ChemSym = "Er"
    elif Z == 69:
        ChemSym = "Tm"
    elif Z == 70:
        ChemSym = "Yb"
    elif Z == 71:
        ChemSym = "Lu"
    elif Z == 72:
        ChemSym = "Hf"
    elif Z == 73:
        ChemSym = "Ta"
    elif Z == 74:
        ChemSym = "W"
    elif Z == 75:
        ChemSym = "Re"
    elif Z == 76:
        ChemSym = "Os"
    elif Z == 77:
        ChemSym = "Ir"
    elif Z == 78:
        ChemSym = "Pt"
    elif Z == 79:
        ChemSym = "Au"
    elif Z == 80:
        ChemSym = "Hg"
    elif Z == 81:
        ChemSym = "Tl"
    elif Z == 82:
        ChemSym = "Pb"
    elif Z == 83:
        ChemSym = "Bi"
    elif Z == 84:
        ChemSym = "Po"
    elif Z == 85:
        ChemSym = "At"
    elif Z == 86:
        ChemSym = "Rn"
    elif Z == 87:
        ChemSym = "Fr"
    elif Z == 88:
        ChemSym = "Ra"
    elif Z == 89:
        ChemSym = "Ac"
    elif Z == 90:
        ChemSym = "Th"
    elif Z == 91:
        ChemSym = "Pa"
    elif Z == 92:
        ChemSym = "U"
    elif Z == 93:
        ChemSym = "Np"
    elif Z == 94:
        ChemSym = "Pu"
    elif Z == 95:
        ChemSym = "Am"
    elif Z == 96:
        ChemSym = "Cm"
    elif Z == 97:
        ChemSym = "Bk"
    elif Z == 98:
        ChemSym = "Cf"
    elif Z == 99:
        ChemSym = "Es"
    elif Z == 100:
        ChemSym = "Fm"
    elif Z == 101:
        ChemSym = "Md"
    elif Z == 102:
        ChemSym = "No"
    elif Z == 103:
        ChemSym = "Lr"
    elif Z == 104:
        ChemSym = "Rf"
    elif Z == 105:
        ChemSym = "Db"
    elif Z == 106:
        ChemSym = "Sg"
    elif Z == 107:
        ChemSym = "Bh"
    elif Z == 108:
        ChemSym = "Hs"
    elif Z == 109:
        ChemSym = "Mt"
    elif Z == 110:
        ChemSym = "Ds"
    elif Z == 111:
        ChemSym = "Rg"
    elif Z == 112:
        ChemSym = "Cn"
    elif Z == 113:
        ChemSym = "Nh"
    elif Z == 114:
        ChemSym = "Fl"
    elif Z == 115:
        ChemSym = "Mc"
    elif Z == 116:
        ChemSym = "Lv"
    elif Z == 117:
        ChemSym = "Ts"
    elif Z == 118:
        ChemSym = "Og"
    elif Z > 118:
        ChemSym = str(Z)
    return ChemSym
